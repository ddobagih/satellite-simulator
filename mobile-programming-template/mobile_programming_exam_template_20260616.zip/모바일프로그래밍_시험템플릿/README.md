# 모바일프로그래밍 시험 템플릿 완성본

## 최종 사용 파일

- `index.html`: 모든 시각 자료, 부분 코드, 조합 코드, 전체 예제, 배치 패턴, 응급 스니펫을 포함한 단일 HTML

## 이번 보강 포인트

- `0. 초압축 목차`: R/L/X 조각과 설정으로 즉시 이동
- `30초 선택표`: 표 + 카드형 선택지 + 문제 단위 여러 조각 복사 버튼
- `배치 패턴`: Scaffold 슬롯, AppBar actions, FAB, bottomNavigationBar, Drawer, TabBar, BottomNavigationBar, Stack, Row/Column 반응형 배치 포함
- `조합 공식`: Scaffold 슬롯 → Body 배치 → 기능 R 조각 → 상태 연결 순서로 조합
- `공통 코드/설정`: import 묶음, pubspec, 권한, Form 검증, 체크박스/라디오, 수정/삭제, Pull-to-refresh, SharedPreferences 추가
- 검색 개선: 공백 AND 검색, 첫 결과 이동, 시험 문장형 별칭 일부 지원

## 백업

- `index_visual_reference.html`: 이전 시각자료 중심 버전 백업
- `index_code_reference.html`: 최초 코드 나열형 버전 백업

보조 폴더(`components/`, `recipes/`, `completed_sources/`, `templates/`)는 남아 있지만, 시험장에서 보는 최종본은 `index.html` 하나입니다.

갱신: 2026-06-16 00:44 KST
